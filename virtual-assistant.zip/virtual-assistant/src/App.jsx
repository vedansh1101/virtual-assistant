import React from "react";
import VirtualAssistant from "./components/VirtualAssistant";

export default function App() {
  return <VirtualAssistant />;
}

